import React, { useState } from "react";

function App() {
  // ROLE: change to "viewer" to test role restriction
  const [role, setRole] = useState("admin");

  // Transactions state
  const [transactions, setTransactions] = useState([
    { id: 1, date: "2026-04-03", category: "Food", amount: 100, type: "expense" },
    { id: 2, date: "2026-04-03", category: "Salary", amount: 5000, type: "income" },
  ]);

  // Search state
  const [searchCategory, setSearchCategory] = useState("");

  // New transaction states (Admin only)
  const [newCategory, setNewCategory] = useState("");
  const [newAmount, setNewAmount] = useState("");
  const [newType, setNewType] = useState("expense");

  // Add transaction function
  const addTransaction = () => {
    if (!newCategory || !newAmount) return;

    const newTx = {
      id: Date.now(),
      date: new Date().toISOString().split("T")[0],
      amount: Number(newAmount),
      category: newCategory,
      type: newType,
    };

    setTransactions([...transactions, newTx]);

    // Clear input fields
    setNewCategory("");
    setNewAmount("");
  };

  // Filtered transactions based on search
  const filteredTransactions = transactions.filter((tx) =>
    tx.category.toLowerCase().includes(searchCategory.toLowerCase())
  );

  // Calculate totals
  const totalIncome = transactions
    .filter((tx) => tx.type === "income")
    .reduce((acc, tx) => acc + tx.amount, 0);

  const totalExpense = transactions
    .filter((tx) => tx.type === "expense")
    .reduce((acc, tx) => acc + tx.amount, 0);

  const balance = totalIncome - totalExpense;

  // Highest spending category
  const expenseTransactions = transactions.filter((tx) => tx.type === "expense");

  const highestCategory = expenseTransactions.reduce(
    (max, tx) => {
      const categoryTotal = expenseTransactions
        .filter((t) => t.category === tx.category)
        .reduce((acc, t) => acc + t.amount, 0);
      return categoryTotal > max.total ? { category: tx.category, total: categoryTotal } : max;
    },
    { category: "N/A", total: 0 }
  );

  return (
    <div className="max-w-5xl mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">Finance Dashboard</h1>

      {/* Role Selector */}
      <div className="mb-4">
        <label className="mr-2 font-semibold">Role:</label>
        <select
          value={role}
          onChange={(e) => setRole(e.target.value)}
          className="border p-1"
        >
          <option value="admin">Admin</option>
          <option value="viewer">Viewer</option>
        </select>
      </div>

      {/* Admin Add Transaction */}
      {role === "admin" && (
        <div className="space-y-2 p-4 mb-4 bg-gray-100 rounded">
          <h2 className="font-bold">Add Transaction</h2>

          <input
            placeholder="Category"
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value)}
            className="border p-2 w-full"
          />

          <input
            type="number"
            placeholder="Amount"
            value={newAmount}
            onChange={(e) => setNewAmount(e.target.value)}
            className="border p-2 w-full"
          />

          <select
            value={newType}
            onChange={(e) => setNewType(e.target.value)}
            className="border p-2 w-full"
          >
            <option value="expense">Expense</option>
            <option value="income">Income</option>
          </select>

          <button
            onClick={addTransaction}
            className="bg-blue-500 text-white px-4 py-2 rounded"
          >
            Add Transaction
          </button>
        </div>
      )}

      {/* Search */}
      <div className="mb-4">
        <input
          placeholder="Search category..."
          value={searchCategory}
          onChange={(e) => setSearchCategory(e.target.value)}
          className="border p-2 w-full"
        />
      </div>

      {/* Insights */}
      <div className="grid grid-cols-4 gap-4 mb-4">
        <div className="p-4 bg-green-100 rounded text-center">
          <h3 className="font-bold">Income</h3>
          <p>₹{totalIncome}</p>
        </div>
        <div className="p-4 bg-red-100 rounded text-center">
          <h3 className="font-bold">Expense</h3>
          <p>₹{totalExpense}</p>
        </div>
        <div className="p-4 bg-blue-100 rounded text-center">
          <h3 className="font-bold">Balance</h3>
          <p>₹{balance}</p>
        </div>
        <div className="p-4 bg-yellow-100 rounded text-center">
          <h3 className="font-bold">Highest Spending</h3>
          <p>
            {highestCategory.category} (₹{highestCategory.total})
          </p>
        </div>
      </div>

      {/* Transactions Table */}
      <table className="w-full border-collapse border">
        <thead>
          <tr className="bg-gray-200">
            <th className="border p-2">Date</th>
            <th className="border p-2">Category</th>
            <th className="border p-2">Amount</th>
            <th className="border p-2">Type</th>
          </tr>
        </thead>
        <tbody>
          {filteredTransactions.map((tx) => (
            <tr key={tx.id}>
              <td className="border p-2">{tx.date}</td>
              <td className="border p-2">{tx.category}</td>
              <td className="border p-2">{tx.amount}</td>
              <td className="border p-2">{tx.type}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Empty state */}
      {filteredTransactions.length === 0 && (
        <p className="text-center mt-4 text-gray-500">No transactions found.</p>
      )}
    </div>
  );
}

export default App;